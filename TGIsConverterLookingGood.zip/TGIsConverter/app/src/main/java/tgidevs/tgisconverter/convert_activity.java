package tgidevs.tgisconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class convert_activity extends AppCompatActivity {

    double inputnumber;
    double midput;
    double outputnumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convert);
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);
        toolbar.setSubtitle(R.string.subtitle);
        final EditText input = (EditText) findViewById(R.id.input);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adaptertime = ArrayAdapter.createFromResource(this, R.array.time, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adaptermass = ArrayAdapter.createFromResource(this, R.array.mass, android.R.layout.simple_spinner_item);
        adaptermass.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adaptertime.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        switch (MainActivity.swc){
                case 0:

                    spinner.setAdapter(adaptertime);
                    toolbar.setSubtitle(R.string.time);
                    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            switch (i){
                                case 0:
                                    Toast.makeText(convert_activity.this, "Jahr", Toast.LENGTH_SHORT).show(); break;
                                case 1:
                                    Toast.makeText(convert_activity.this, "Woche", Toast.LENGTH_SHORT).show(); break;
                            }
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {

                        }
                    });


                    break;

                case 1:
                    spinner.setAdapter(adaptermass);
                    toolbar.setSubtitle(R.string.weight);
                    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            switch (i){
                                case 0:
                                    Toast.makeText(convert_activity.this, "Tonne", Toast.LENGTH_SHORT).show(); break;
                                case 1:
                                    Toast.makeText(convert_activity.this, "Doppelzentner", Toast.LENGTH_SHORT).show(); break;
                            }
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {

                        }
                    });
                    break;

        }


    }


}





